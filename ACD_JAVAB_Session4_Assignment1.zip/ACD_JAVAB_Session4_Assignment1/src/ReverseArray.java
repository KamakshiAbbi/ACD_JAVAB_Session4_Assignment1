//Session4_Assignment1 : 8.5.2016
//Author: Kamakshi Abbi
import java.util.Scanner;
public class ReverseArray {
	public static void Reverse(){
		int arr[] = new int[5];
		System.out.println("Enter 5 numbers of the array");
		Scanner input = new Scanner(System.in);
		for (int i = 0; i < arr.length; i++) {
			arr[i] = input.nextInt();
		}
		input.close();	
		System.out.println("Reverse of array");
		for (int j = arr.length - 1 ; j >= 0; j--) {
			System.out.print(arr[j]+" ");
		}
	}
	public static void main(String[] args) {
		Reverse();
	}
	
}
